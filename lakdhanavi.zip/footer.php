<footer data-scroll-section="">
            <div class="container--v">
                <div class="f-country-s">
                    <div
                            class="swiper flagSlider swiper-initialized swiper-horizontal swiper-pointer-events swiper-free-mode">
                        <div class="swiper-wrapper"
                             style="cursor: grab; transform: translate3d(-2416.67px, 0px, 0px); transition-duration: 5000ms;"
                             id="swiper-wrapper-6bb31e8f5a3d81d4" aria-live="off">

                            <div class="swiper-slide" data-swiper-slide-index="0"
                                 style="width: 110.833px; margin-right: 10px;" role="group" aria-label="1 / 18">
                                <a href="#singapore">
                                    <img src="./assets/images/flag/singapore.jpg" alt="flag">
                                </a>
                            </div>

                            <div class="swiper-slide" data-swiper-slide-index="1"
                                 style="width: 110.833px; margin-right: 10px;" role="group" aria-label="2 / 18">
                                <a href="#bangladesh">
                                    <img src="./assets/images/flag/bangladesh.jpg" alt="flag">
                                </a>
                            </div>

                            <div class="swiper-slide" data-swiper-slide-index="2"
                                 style="width: 110.833px; margin-right: 10px;" role="group" aria-label="3 / 18">
                                <a href="#india">
                                    <img src="./assets/images/flag/india.jpg" alt="flag">
                                </a>
                            </div>

                            <div class="swiper-slide" data-swiper-slide-index="3"
                                 style="width: 110.833px; margin-right: 10px;" role="group" aria-label="4 / 18">
                                <a href="#nepal">
                                    <img src="./assets/images/flag/nepal.jpg" alt="flag">
                                </a>
                            </div>

                            <div class="swiper-slide" data-swiper-slide-index="4"
                                 style="width: 110.833px; margin-right: 10px;" role="group" aria-label="5 / 18">
                                <a href="#srilanka">
                                    <img src="./assets/images/flag/srilanka.jpg" alt="flag">
                                </a>
                            </div>

                            <div class="swiper-slide" data-swiper-slide-index="5"
                                 style="width: 110.833px; margin-right: 10px;" role="group" aria-label="6 / 18">
                                <a href="#brazil">
                                    <img src="./assets/images/flag/brazil.jpg" alt="flag">
                                </a>
                            </div>

                            <div class="swiper-slide" data-swiper-slide-index="6"
                                 style="width: 110.833px; margin-right: 10px;" role="group" aria-label="7 / 18">
                                <a href="#iceland">
                                    <img src="./assets/images/flag/iceland.jpg" alt="flag">
                                </a>
                            </div>

                            <div class="swiper-slide swiper-slide-prev" data-swiper-slide-index="7"
                                 style="width: 110.833px; margin-right: 10px;" role="group" aria-label="8 / 18">
                                <a href="#us">
                                    <img src="./assets/images/flag/us.jpg" alt="flag">
                                </a>
                            </div>

                            <div class="swiper-slide swiper-slide-active" data-swiper-slide-index="8"
                                 style="width: 110.833px; margin-right: 10px;" role="group" aria-label="9 / 18">
                                <a href="#nigeria">
                                    <img src="./assets/images/flag/nigeria.jpg" alt="flag">
                                </a>
                            </div>

                            <div class="swiper-slide swiper-slide-next" data-swiper-slide-index="9"
                                 style="width: 110.833px; margin-right: 10px;" role="group" aria-label="10 / 18">
                                <a href="#south-africa">
                                    <img src="./assets/images/flag/south-africa.jpg" alt="flag">
                                </a>
                            </div>

                            <div class="swiper-slide" data-swiper-slide-index="10"
                                 style="width: 110.833px; margin-right: 10px;" role="group" aria-label="11 / 18">
                                <a href="#sudan">
                                    <img src="./assets/images/flag/sudan.jpg" alt="flag">
                                </a>
                            </div>

                            <div class="swiper-slide" data-swiper-slide-index="11"
                                 style="width: 110.833px; margin-right: 10px;" role="group" aria-label="12 / 18">
                                <a href="#turkey">
                                    <img src="./assets/images/flag/turkey.jpg" alt="flag">
                                </a>
                            </div>

                            <div class="swiper-slide" data-swiper-slide-index="12"
                                 style="width: 110.833px; margin-right: 10px;" role="group" aria-label="13 / 18">
                                <a href="#south-africa.jpg">
                                    <img src="./assets/images/flag/south-africa.jpg" alt="flag">
                                </a>
                            </div>

                            <div class="swiper-slide" data-swiper-slide-index="13"
                                 style="width: 110.833px; margin-right: 10px;" role="group" aria-label="14 / 18">
                                <a href="#us">
                                    <img src="./assets/images/flag/us.jpg" alt="flag">
                                </a>
                            </div>

                            <div class="swiper-slide" data-swiper-slide-index="14"
                                 style="width: 110.833px; margin-right: 10px;" role="group" aria-label="15 / 18">
                                <a href="#turkey">
                                    <img src="./assets/images/flag/turkey.jpg" alt="flag">
                                </a>
                            </div>

                            <div class="swiper-slide" data-swiper-slide-index="15"
                                 style="width: 110.833px; margin-right: 10px;" role="group" aria-label="16 / 18">
                                <a href="#bangladesh">
                                    <img src="./assets/images/flag/bangladesh.jpg" alt="flag">
                                </a>
                            </div>

                            <div class="swiper-slide" data-swiper-slide-index="16"
                                 style="width: 110.833px; margin-right: 10px;" role="group" aria-label="17 / 18">
                                <a href="#nigeria">
                                    <img src="./assets/images/flag/nigeria.jpg" alt="flag">
                                </a>
                            </div>

                            <div class="swiper-slide" data-swiper-slide-index="17"
                                 style="width: 110.833px; margin-right: 10px;" role="group" aria-label="18 / 18">
                                <a href="#sudan">
                                    <img src="./assets/images/flag/sudan.jpg" alt="flag">
                                </a>
                            </div>

                        </div>
                        <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span>

                        <hr>
                    </div>
                    <span></span>

                </div>


                <div class="wrap-footer">
                    <div class="footer-log-sec">
                        <div class="logos">
                            <img src="./assets/images/logo/logo-with-sister-concern.png" class="footer-logo" alt="lolc-logo">

                        </div>
<!--                        <div class="phone-number">-->
<!--                            <h4>info@lakdhanavi.com</h4>-->
<!--                        </div>-->
                    </div>

                    <div class="quick-links-wrap">
                        <ul class="quick-links">
                            <li>
                                <a href="#">Global</a>
                            </li>
                            <li>
                                <a href="#">ESG</a>
                            </li>
<!--                            <li>-->
<!--                                <a href="#">Investor Relations</a>-->
<!--                            </li>-->
                            <li>
                                <a href="#">About us</a>
                            </li>
                            <li>
                                <a href="#">News</a>
                            </li>
                            <li>
                                <a href="#">Media</a>
                            </li>
                            <li>
                                <a href="#" target="_blank">Careers</a>
                            </li>
                            <li>
                                <a href="#">Contact Us</a>
                            </li>
                        </ul>
                        <div class="sector-wrap">
                            <div class="sector">
                                <h5>Sectors</h5>
                                <ul>
                                    <li>
                                        <a href="#">Financial Services</a>
                                    </li>
                                    <li>
                                        <a href="#">Leisure</a>
                                    </li>

                                    <li>
                                        <a href="#">Construction</a>
                                    </li>
                                    <li>
                                        <a href="#">Agriculture &amp;
                                            Plantations</a>
                                    </li>
                                    <li>
                                        <a href="#">Strategic Investment</a>
                                    </li>
                                    <li>
                                        <a href="#">Manufacturing &amp; Trading</a>
                                    </li>
                                    <li>
                                        <a href="#">Research &amp;
                                            Innovation</a>
                                    </li>
                                    <li>
                                        <a href="#">Digital Empowerment</a>
                                    </li>
                                    <li>
                                        <a href="#">Mining</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="wrap-follow-us">
                                <div class="follow-us">
                                    <h5>Follow us on:</h5>
                                    <ul>
                                        <li>
                                            <a href="#" target="_blank">
                                                <img src="./assets/images/footer/fb.png" alt="social-media-icon-fb">
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#" target="_blank">
                                                <img src="./assets/images/footer/insta.png"
                                                    alt="social-media-icon-insta">
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#" target="_blank">
                                                <img src="./assets/images/footer/youtube.png"
                                                    alt="social-media-icon-youtube">
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#" target="_blank">
                                                <img src="./assets/images/footer/tweeter.png"
                                                    alt="social-media-icon-twitter">
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#" target="_blank">
                                                <img src="./assets/images/footer/linkdin.png"
                                                    alt="social-media-icon-linkd-in">
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="ft-bottom-wrap">
                    <p class="copyright">© 2023 Lakdhanavi Group</p>
                    <p class="desing-dev">Design and develop by <a href="https://www.quicksms.xyz"
                            target="_blank">QUICK HOST BD</a>
                    </p>
                </div>
            </div>
        </footer>

    </main>

<script>
    // 1. querySelector
    var containerEl = document.querySelector(".portfolio-item");
    // 2. Passing the configuration object inline
    //https://www.kunkalabs.com/mixitup/docs/configuration-object/
    var mixer = mixitup(containerEl, {
        animation: {
            effects: "fade translateZ(-100px)",
            effectsIn: "fade translateY(-100%)",
            easing: "cubic-bezier(0.645, 0.045, 0.355, 1)"
        }
    });
    // fancybox insilaze & options
    $("[data-fancybox]").fancybox({
        loop: true,
        hash: true,
        transitionEffect: "slide",
        /* zoom VS next
        clickContent - i modify the deafult - now when you click on the image you go to the next image - i more like this approach than zoom on desktop (This idea was in the classic/first lightbox) */
        clickContent: function(current, event) {
            return current.type === "image" ? "next" : false;
        }
    });
</script>

    <script>
        // var siteBaseUrl = "localhost";

        var siteBaseUrl = "https://www.lolc.com";

    </script>



    <script src="./assets/js/lib.js"></script>
    <script src="./assets/js/main.js"></script>
    <script src="./assets/js/swiperslider.min.js"></script>


</body>

</html>